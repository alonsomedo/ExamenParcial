package edu.progra2.loanMedinaDonayre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanMedinaDonayreApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanMedinaDonayreApplication.class, args);
	}
}
